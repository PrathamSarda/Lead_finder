"""
Example backend test — verifies the health check endpoint responds.
Run with: pytest tests/backend
"""
from fastapi.testclient import TestClient

from backend.app.main import app

client = TestClient(app)


def test_health_check():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
