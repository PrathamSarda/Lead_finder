from automation.enrichment.regex_patterns import EMAIL_PATTERN


def extract_emails(html: str) -> list[str]:
    """
    Extracts all email addresses from HTML.
    """

    emails = EMAIL_PATTERN.findall(html)

    unique = []

    for email in emails:
        email = email.lower()

        if email not in unique:
            unique.append(email)

    return unique
